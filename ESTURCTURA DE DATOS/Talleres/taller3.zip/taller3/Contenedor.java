public class Contenedor {
    private int numeroC;
    private String nombreEmpresa;
     
    
    public Contenedor(int numeroC, String nombreEmpresa) {
        this.numeroC = numeroC;
        this.nombreEmpresa = nombreEmpresa;
    }
    
    public int getNumeroC() {
        return numeroC;
    }
    public void setNumeroC(int numeroC) {
        this.numeroC = numeroC;
    }
    public String getNombreEmpresa() {
        return nombreEmpresa;
    }
    public void setNombreEmpresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    

}
