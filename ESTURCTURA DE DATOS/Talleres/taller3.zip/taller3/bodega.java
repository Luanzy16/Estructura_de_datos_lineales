import java.util.ArrayList;
import java.util.Stack;

public class bodega {
    static ArrayList<Contenedor> lista = new ArrayList<>();
    static Stack<Contenedor> pila1 = new Stack<>();

    static void llenar(){   
        for(int i=0; i<10; i++){
            int numero = (int)(Math.random()*10+1);
            pila1.push(new Contenedor(i, "empresa "+numero));
            System.out.println(pila1.elementAt(i).getNumeroC());
            
        }
    }

    static void buscar(int numero){
        while(!pila1.isEmpty()){
            if(pila1.peek().getNumeroC() != numero){
                Contenedor e = pila1.pop();
                lista.add(e);
            }
            else{
                System.out.println("El contenedor solicitado: "+ pila1.peek().getNumeroC()+" De la empresa: "+ pila1.peek().getNombreEmpresa());
                break;
            }
        }
    }

    static void apilar(){
        while(!lista.isEmpty()){
            Contenedor p = lista.remove(lista.size()-1);
            pila1.push(p);
            System.out.println(pila1.peek().getNumeroC());
        
        }
    }
        
    

    public static void main(String[] args) {
        llenar();
        buscar(5);
        apilar();
    }
}
