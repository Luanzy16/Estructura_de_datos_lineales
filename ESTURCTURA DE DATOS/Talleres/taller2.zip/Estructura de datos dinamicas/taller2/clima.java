package taller2;

import listas.Lista;

public class clima {
    static Lista<Integer> lista = new Lista<>();
    public static void main(String[] args) {
        

        for (int i = 0; i < 3; i++) {
            lista.agregarInicio((int) (Math.random() * (12) + 1));
            lista.agregarFinal((int) (Math.random() * (4) + 1));
            lista.agregarFinal((int) (Math.random() * (7) + 1));
            lista.agregarFinal((int) (Math.random() * (30)));
        }

        lista.mostrarLista();

    }

    public static void registroClima(int mes) {
        
        
    }
}
